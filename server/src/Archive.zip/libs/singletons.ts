import { Randomizer } from "./Randomizer";

let r = new Randomizer(Date.now());

export { r };
