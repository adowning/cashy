import { BunRequest } from "bun";
import { NETWORK_CONFIG, User } from "shared";
import { getUserFromHeader } from "../auth";
import type {
  GetDepositResponse,
  SubmitDepositResponse,
  GetDepositHistoryResponse,
  GetProductsResponse,
  ProductWithoutTransactions,
  GetOperatorDataResponse,
  OperatorData,
} from "shared/interface/deposit";
import db from "../../db/prisma";

export async function getDepositConfig(req: BunRequest): Promise<Response> {
  const config = {
    bonus: [{ type: 0 }],
    methods: [
      {
        id: "pix",
        icon: "payment/pix.png",
        name: "PIX",
        min: 10,
        max: 5000,
      },
    ],
  };

  const response: GetDepositResponse = {
    code: 200,
    data: config,
    message: "Success",
  };

  return new Response(JSON.stringify(response));
}
export async function getProducts(req: BunRequest): Promise<Response> {
  const products = await db.product.findMany({
    orderBy: { priceInCents: "asc" },
    include: {
      // operator: true,
      // transactions: true,
    },
  });

  const response: GetProductsResponse = {
    code: 200,
    products,
    message: "Products",
  };

  return new Response(JSON.stringify(response));
}

export async function getOperatorData(req: BunRequest, user: User): Promise<Response> {
  const _operator = await db.operator.findUnique({
    where: {
      id: user.activeProfile.shopId as string,
    },
    include: {
      products: true,
    },
  });
  if (_operator == null) throw new Error("Operator not found");
  const products: ProductWithoutTransactions[] = _operator.products.map((product): ProductWithoutTransactions => {
    return {
      id: product.id,
      priceInCents: product.priceInCents,
      description: product.description,
      transactions: [],
      title: product.title,
      url: product.url,
      type: product.type,
      bonusCode: null,
      bonusTotalInCredits: null,
      amountToReceiveInCredits: 0,
      bestValue: 0,
      discountInCents: 0,
      bonusSpins: null,
      isPromo: null,
      totalDiscountInCents: 0,
      shopId: null,
      createdAt: product.createdAt,
      updatedAt: null,
      operator: null,
    };
  });

  const operator: OperatorData = {
    id: _operator.id,
    acceptedPayments: _operator.acceptedPayments,
    products,
  };
  const response: GetOperatorDataResponse = {
    code: 200,
    operator,
    message: "Operator data with products",
  };

  return new Response(JSON.stringify(response));
}

export async function submitDeposit(req: BunRequest, user: User): Promise<Response> {
  const data = await req.json();
  const deposit = await db.transaction.create({
    data: {
      type: "DEPOSIT",
      amount: Number(data.amount),
      profileId: user.activeProfileId as string,
      status: "PENDING",
      paymentMethod: data.method,
      metadata: data.details,
    },
  });

  const response: SubmitDepositResponse = {
    code: 200,
    data: {
      transactionId: deposit.id,
      status: deposit.status,
    },
    message: "Deposit submitted",
  };

  return new Response(JSON.stringify(response));
}

export async function getDepositHistory(req: BunRequest, user: User): Promise<Response> {
  const params = new URL(req.url).searchParams;
  const page = Number(params.get("page")) || 1;
  const limit = Number(params.get("limit")) || 10;
  const [count, records] = await Promise.all([
    db.transaction.count({
      where: {
        profileId: user.activeProfileId as string,
        type: "DEPOSIT",
      },
    }),
    db.transaction.findMany({
      where: {
        profileId: user.activeProfileId as string,
        type: "DEPOSIT",
      },
      include: {
        product: true,
      },
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * limit,
      take: limit,
    }),
  ]);

  const statusarray = ["PENDING", "COMPLETED", "FAILED", "CANCELLED", "REFUNDED", "EXPIRED", "REJECTED"];
  const response: GetDepositHistoryResponse = {
    code: 200,
    data: {
      total_pages: Math.ceil(count / limit),
      record: records.map((t) => ({
        id: Number(t.id),
        created_at: Math.floor(t.createdAt.getTime() / 1000),
        type: t.type,
        product: t.product,
        amount: t.amount.toString(),
        status: statusarray[t.status], // === "COMPLETED" ? 1 : 0,
        note: "",
        currency: "USD",
      })),
    },
    message: "Success",
  };

  return new Response(JSON.stringify(response));
}

export async function depositRoutes(req: BunRequest, route: string): Promise<Response | boolean> {
  console.log("x");

  const user = await getUserFromHeader(req);
  if (!user || !user.activeProfile) {
    return new Response(
      JSON.stringify({
        code: 401,
        message: "Unauthorized",
        data: { total_pages: 0, record: [] },
      }),
      { status: 401 }
    );
  }
  console.log("x");

  try {
    switch (route) {
      case NETWORK_CONFIG.DEPOSIT_PAGE.DEPOSIT_CONFIG:
        return await getDepositConfig(req);
      case NETWORK_CONFIG.DEPOSIT_PAGE.PRODUCTS:
        return await getProducts(req);
      case NETWORK_CONFIG.DEPOSIT_PAGE.OPERATOR_DATA:
        return await getOperatorData(req, user);
      case NETWORK_CONFIG.DEPOSIT_PAGE.DEPOSIT_SUBMIT:
        return await submitDeposit(req, user);
      case NETWORK_CONFIG.DEPOSIT_PAGE.DEPOSIT_HISTORY:
        return await getDepositHistory(req, user);
      default:
        return false;
    }
  } catch (error) {
    console.error(error);
    return new Response(
      JSON.stringify({
        message: `Internal server error: ${error}`,
        code: 500,
      }),
      { status: 500 }
    );
  }
}
