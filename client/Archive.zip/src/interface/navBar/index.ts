export interface GetGameOriginalData {
    icon: string
    name: string
}