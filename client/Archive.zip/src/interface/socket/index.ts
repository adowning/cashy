export interface GetUserBalance {
    bal: string | number
    cur: string
    mt: number
}