export interface GetUserData {
    id: string
    avatar: string
    name: string
    grade_level: string
    grade: string
    wallet: number | string
    currency: string
}