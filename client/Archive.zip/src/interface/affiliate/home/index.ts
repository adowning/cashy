export interface LiveWinItem {
    image: any
    level: number
    game_name: string
    betting_amount: number | string
}