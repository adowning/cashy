// import { createRouter, createWebHistory } from 'vue-router'
// import routes from '../views'

// export const router = createRouter({
//   routes,
//   history: createWebHistory(),
// })
