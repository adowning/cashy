// import { createAuthClient } from 'better-auth/vue'
// import { bearer } from 'better-auth/plugins'

// export const authClient = createAuthClient({
//   /** The base URL of the server (optional if you're using the same domain) */
//   baseURL: 'http://localhost:3001',
//   emailAndPassword: {
//     enabled: true,
//   },
//   fetchOptions: {
//     baseURL: 'http://localhost:3001/auth',
//     //  bearer()
//   },
// })
