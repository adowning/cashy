export type WebSocketStatus = 'OPEN' | 'CONNECTING' | 'CLOSED';
