export type CashflowAction = {
  enabled: boolean
  group: string
  id: string
  name: string
  subaction_count: number
}
