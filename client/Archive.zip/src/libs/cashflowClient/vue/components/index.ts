import cashflowGlobalVariable from './CashflowGlobalVariable.vue'

export { cashflowGlobalVariable }
