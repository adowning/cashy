export const INJECT_CLIENT = Symbol('cashflow-client')
export const INJECT_CLIENT_STATUS = Symbol('cashflow-client-status')
