// export const containerMaxW = 'xl:max-w-6xl xl:mx-auto'
export const containerMaxW = 'xl:max-w-[600px] xl:mx-auto lg:max-w-[600px] lg:mx-auto md:max-w-[600px] md:mx-auto sm:max-w-[600px] sm:mx-auto xs:max-w-[600px] xs:mx-auto'
