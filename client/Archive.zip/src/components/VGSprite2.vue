<script setup lang="ts">
import type { PropType } from 'vue'
import { computed, onMounted, ref, watch } from 'vue'
import type { StyleValue } from 'vue' // Import StyleValue type

interface FrameData {
  x: number
  y: number
  w: number
  h: number
}

export interface SpriteFrame {
  filename: string // Added filename as it's in your JSON array
  frame: FrameData // The position and size of the sprite within the texture
  rotated: boolean
  trimmed: boolean // Indicates if the sprite was trimmed
  spriteSourceSize: FrameData // The size of the sprite before trimming
  sourceSize: FrameData // The original size of the sprite before packing
}

// Corrected SpriteSheetData interface to match the provided JSON structure
export interface SpriteSheetData {
  frames: SpriteFrame[] // frames is an array of SpriteFrame
  // Removed the metadata property as it's not in the provided JSON structure
}

const props = defineProps({
  spriteSheetData: {
    type: Object as PropType<SpriteSheetData>, // Use the corrected interface
    required: true,
  },
  imageSrc: {
    type: String,
    required: true,
  },
  speed: {
    type: Number,
    required: true, // Frames per second for the animation
  },
  offset: {
    type: Number,
    required: false, // Delay before starting the animation loop
    default: 0,
  },
  delay: {
    type: Number,
    required: false, // Delay after one animation loop before the next (if not infinite)
    default: 0,
  },
  autoPlay: {
    type: Boolean,
    required: false,
    default: true,
  },
  maxWidth: {
    type: Number,
    required: false, // Desired display width (for scaling)
    default: 0, // If 0, use the source sprite width
  },
  maxHeight: {
    type: Number,
    required: false, // Desired display height (for scaling)
    default: 0, // If 0, use the source sprite height
  },
  loop: {
    type: Boolean,
    required: false,
    default: true, // Whether the animation should loop
  },
  // Added a prop for the actual spritesheet dimensions, as metadata is missing in the JSON
  spritesheetDimensions: {
    type: Object as PropType<{ w: number; h: number }>,
    required: true, // Require spritesheet dimensions
  },
})

const currentFrameIndex = ref(0)
const animationInterval = ref<number | null>(null) // To store the interval ID

// Frame data is now directly the array from props
const frames = computed(() => props.spriteSheetData.frames)
const totalFrames = computed(() => frames.value.length)

// Get the data for the current frame by index
const currentFrameData = computed(() =>
  frames.value.length > 0 ? frames.value[currentFrameIndex.value] : null,
)

// Style for the sprite element, including scaling and background positioning
const spriteStyle = computed<StyleValue>(() => {
  // Return a default style object if data is not ready
  if (!currentFrameData.value || !props.spritesheetDimensions) {
    // Check for currentFrameData and spritesheetDimensions prop
    return {
      width: props.maxWidth > 0 ? `${props.maxWidth}px` : '0px',
      height: props.maxHeight > 0 ? `${props.maxHeight}px` : '0px',
      backgroundImage: 'none',
      backgroundSize: 'auto',
      backgroundPosition: '0 0',
      backgroundRepeat: 'no-repeat',
      transform: 'none',
      transformOrigin: 'center',
      imageRendering: 'auto',
    }
  }

  const frame = currentFrameData.value.frame
  const rotated = currentFrameData.value.rotated
  const spritesheetWidth = props.spritesheetDimensions.w
  const spritesheetHeight = props.spritesheetDimensions.h

  // Calculate the desired element size based on maxWidth/maxHeight
  const elementWidth = props.maxWidth > 0 ? props.maxWidth : frame.w // Use frame.w/h as fallback if max not set
  const elementHeight = props.maxHeight > 0 ? props.maxHeight : frame.h

  // Calculate the scaling factors based on desired element size vs the frame's texture rectangle size
  const scaleFactorX = elementWidth / frame.w
  const scaleFactorY = elementHeight / frame.h

  // Calculate the background size: Scale the entire spritesheet by the same factor
  const bgSizeWidth = spritesheetWidth * scaleFactorX
  const bgSizeHeight = spritesheetHeight * scaleFactorY

  // Calculate the background position: Position the background to show the current frame, scaled
  // The position is the negative of the frame's texture rectangle coordinates, scaled.
  let bgPositionX = -frame.x * scaleFactorX
  let bgPositionY = -frame.y * scaleFactorY

  // Adjust background position if the frame is rotated in the spritesheet
  // This part is complex and depends on the sprite packer's rotation logic.
  // For the provided JSON, rotated is false, so this block is not strictly needed
  // but kept for completeness if you use spritesheets with rotation.
  // If you encounter issues with rotated frames, this calculation might need
  // specific adjustments based on your sprite packing tool's output.
  if (rotated) {
    // Example adjustment (might need refinement):
    // When rotated 90deg clockwise, the frame's original top-left (x,y) becomes
    // the top-right of the rotated frame in the spritesheet.
    // The background position needs to shift to compensate.
    // This is a simplified example; real-world adjustment depends heavily on the packer.
    // For a 90deg clockwise rotation:
    // New X position should correspond to original Y
    // New Y position should correspond to original X, adjusted by original width
    // bgPositionX = -(frame.y + frame.h) * scaleFactorX; // This is just an example, likely incorrect
    // bgPositionY = -frame.x * scaleFactorY; // This is just an example, likely incorrect
    // A more robust approach often involves considering the original source size and offset
    // if available in the JSON, which your provided JSON does have (spriteSourceSize, sourceSize, spriteOffset).
    // However, without a clear example of a rotated frame in your data and how the packer
    // handles it, providing a precise calculation is difficult.
    // Let's stick to the non-rotated case which is relevant for your coin.
  }

  return {
    width: `${elementWidth}px`,
    height: `${elementHeight}px`,
    backgroundImage: `url(${props.imageSrc})`,
    backgroundSize: `${bgSizeWidth}px ${bgSizeHeight}px`,
    backgroundPosition: `${bgPositionX}px ${bgPositionY}px`,
    backgroundRepeat: 'no-repeat',
    // Apply element rotation if the frame is rotated in the spritesheet
    transform: rotated ? 'rotate(90deg)' : 'none', // Rotate the element itself
    transformOrigin: 'center', // Rotate around the center of the element
    imageRendering: 'pixelated', // or 'crisp-edges' for sharper look. Consider alternatives if blurry.
  }
})

// Function to start the sprite animation
function startAnimation() {
  if (animationInterval.value !== null || totalFrames.value <= 1) {
    return // Animation is already playing or there's only one frame
  }

  // Calculate the interval time based on speed (frames per second)
  const intervalTime = 1000 / props.speed

  // Start the interval after an initial offset delay
  setTimeout(() => {
    animationInterval.value = setInterval(() => {
      currentFrameIndex.value = (currentFrameIndex.value + 1) % totalFrames.value

      // If looping is false and we've reached the last frame, stop the animation
      if (!props.loop && currentFrameIndex.value === totalFrames.value - 1) {
        stopAnimation()
      }
    }, intervalTime) as unknown as number // Cast to number for clearInterval type compatibility
  }, props.offset) // Initial delay before the first frame change
}

// Function to stop the sprite animation
function stopAnimation() {
  if (animationInterval.value !== null) {
    clearInterval(animationInterval.value)
    animationInterval.value = null
  }
}

// Watch for changes in autoPlay prop to start/stop animation
watch(
  () => props.autoPlay,
  (newVal) => {
    if (newVal) {
      startAnimation()
    } else {
      stopAnimation()
    }
  },
  { immediate: true },
) // Start immediately if autoPlay is true on mount

// Watch for changes in speed or frame data that might require restarting the animation
watch([() => props.speed, () => props.spriteSheetData], () => {
  // Stop current animation and restart if autoPlay is true
  stopAnimation()
  // Reset frame index when data changes
  currentFrameIndex.value = 0
  if (props.autoPlay) {
    startAnimation()
  }
})

onMounted(() => {
  // Animation is now controlled by the autoPlay watcher
})

onUnmounted(() => {
  stopAnimation() // Clean up interval on unmount
})
</script>

<template>
  <div :style="spriteStyle"></div>
</template>
