<script lang="ts" setup></script>

<template>
    <img src="@/assets/public/svg/icon_public_18.svg" />
</template>