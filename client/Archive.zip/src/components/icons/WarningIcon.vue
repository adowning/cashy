<script lang="ts" setup></script>

<template>
    <img src="@/assets/public/svg/icon_public_17.svg" />
</template>