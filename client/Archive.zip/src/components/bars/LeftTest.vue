<template>
    
    <div data-v-905a027d="" class="content leftBar">
        <div data-v-736008e0="" data-v-905a027d="" class="toolbar header-mobile">
            <div data-v-a0f50dc4="" data-v-736008e0="" class="header-info">
                <div data-v-7430c134="" data-v-a0f50dc4="" class="widget">
                    <div data-v-7430c134="" class="content"><span data-v-589d9d3d="" data-v-7430c134=""
                            class="fs medium counter" style="--69ca8741: 8px;">3</span><span data-v-7430c134=""
                            class="nuxt-icon arrow"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                viewBox="0 0 24 24" fill="none">
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M6.29307 9.29272C5.90245 9.68314 5.90229 10.3163 6.29272 10.7069L11.2902 15.7069C11.4777 15.8945 11.732 15.9999 11.9973 16C12.2625 16.0001 12.5168 15.8948 12.7044 15.7073L17.7069 10.7073C18.0976 10.3169 18.0977 9.68369 17.7073 9.29307C17.3169 8.90245 16.6837 8.90229 16.2931 9.29272L11.9979 13.5858L7.70728 9.29307C7.31686 8.90245 6.68369 8.90229 6.29307 9.29272Z"
                                    fill="white"></path>
                            </svg></span><span data-v-7430c134="" class="nuxt-icon close"><svg
                                xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"
                                fill="none">
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M2.92764 2.92732C3.27477 2.5802 3.83757 2.58022 4.18469 2.92735L8.00042 6.74326L11.8155 2.92855C12.1626 2.58144 12.7254 2.58146 13.0725 2.9286C13.4196 3.27574 13.4196 3.83855 13.0725 4.18566L9.25744 8.00035L13.0728 11.8158C13.4199 12.163 13.4199 12.7258 13.0727 13.0729C12.7256 13.42 12.1628 13.42 11.8157 13.0729L8.00033 9.25734L4.184 13.0733C3.83686 13.4205 3.27405 13.4204 2.92694 13.0733C2.57983 12.7261 2.57986 12.1633 2.927 11.8162L6.74331 8.00026L2.92761 4.18438C2.58049 3.83724 2.5805 3.27444 2.92764 2.92732Z"
                                    fill="white"></path>
                            </svg></span></div>
                </div><a data-v-38f37fee="" data-v-a0f50dc4="" class="avatar-progress"
                    style="--7fb7ed2e: 307.8758146928204;"><img data-v-38f37fee="" src="/images/bronze.webp" width="40"
                        height="40" alt="status" data-nuxt-img="" srcset="/images/bronze.webp" class="status"><span
                        data-v-38f37fee="" class="nuxt-icon"><svg xmlns="http://www.w3.org/2000/svg" focusable="false"
                            viewBox="55.55555555555556 55.55555555555556 111.11111111111111 111.11111111111111"
                            aria-hidden="true" style="transform: rotate3d(0, 0, 1, -90deg)">
                            <defs>
                                <linearGradient id="myGradient" gradientTransform="rotate(300)">
                                    <stop offset="0%" stop-color="#EC742B"></stop>
                                    <stop offset="40%" stop-color="#EFD032"></stop>
                                </linearGradient>
                            </defs>
                            <circle fill="transparent" stroke="#232561" stroke-width="8" stroke-dasharray="314.159"
                                stroke-dashoffset="0" cx="111.11111111111111" cy="111.11111111111111" r="50" style="
              transition:
                  stroke-dashoffset 0.6s ease 0s,
                  stroke 0.6s ease 0s;
          "></circle>
                            <circle fill="transparent" stroke="url(#myGradient)" stroke-width="8"
                                stroke-dasharray="314.159" stroke-dashoffset="320" cx="111.11111111111111"
                                cy="111.11111111111111" r="50" class="progress-circle" style="
              transition:
                  stroke-dashoffset 0.6s ease 0s,
                  stroke 0.6s ease 0s;
              stroke-linecap: round;
          "></circle>
                        </svg>
                    </span></a>
                <div data-v-8591201f="" data-v-a0f50dc4="" class="balance-tabs switcher is-blurred"><!---->
                    <div data-v-8591201f="" class="balance-tab">
                        <div data-v-177f469a="" data-v-8591201f="" class="prize coins"
                            style="--62108422: 40px; --25845d48: 8px; --225ea412: 40px;"><!----><img data-v-177f469a=""
                                src="/images/coins.png" width="160" height="160" alt="coins" data-nuxt-img=""
                                srcset="/images/coins.png"><span data-v-589d9d3d="" data-v-8591201f=""
                                data-v-177f469a-s="" class="topeka bold ellipsis text-coimbatore"
                                data-tid="points-coins"><span data-v-8591201f=""
                                    data-v-589d9d3d-s="">101,720</span></span></div>
                    </div><span data-v-8591201f="" class="nuxt-icon" style="display: none;"><svg width="20" height="20"
                            viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M16.25 13.125L10.0031 6.875L3.75 13.125" stroke="#7D77E9" stroke-width="2"
                                stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                    </span><span data-v-8591201f="" class="nuxt-icon"><svg width="20" height="20" viewBox="0 0 20 20"
                            fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M16.25 6.875L10.0031 13.125L3.75 6.875" stroke="#7D77E9" stroke-width="2"
                                stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg>
                    </span>
                </div><!----><!----><!---->
            </div>
            <div data-v-736008e0="" class="balance">
                <div data-v-47d865f7="" data-v-736008e0="" class="mode-toggle"><label data-v-db1a90ab=""
                        data-v-47d865f7="" class="toggle"
                        style="--87de9db2: var(--canberra); --717315bd: 12px; --24e95dfc: 0.2;"><input
                            data-v-db1a90ab="" checked="" type="checkbox" class="input">
                        <div data-v-db1a90ab="" class="inner truthy">
                            <div data-v-db1a90ab="" class="track"></div>
                            <div data-v-db1a90ab="" class="thumb"></div>
                        </div><!---->
                    </label></div><button data-v-517ae0ee="" data-v-736008e0=""
                    class="a-button primary size-md buy-button"> +
                </button>
            </div>
        </div>
        <div data-v-905a027d="" class="header">
            <div data-v-905a027d="" class="game-left"><button data-v-517ae0ee="" data-v-905a027d=""
                    class="a-button toolbar" data-tid="add-favorite"><span data-v-905a027d="" class="nuxt-icon"><svg
                            xmlns="http://www.w3.org/2000/svg" width="16" height="14" viewBox="0 0 16 14" fill="none">
                            <path fill-rule="evenodd" clip-rule="evenodd"
                                d="M15 4.65455C15.0002 2.65731 13.2863 1.02981 11.1514 1C9.88784 1.01174 8.71093 1.60296 8.00259 2.58182C7.29425 1.60296 6.11733 1.01174 4.85376 1C2.71885 1.02981 1.00494 2.65731 1.00518 4.65455C0.998273 4.78174 0.998273 4.90917 1.00518 5.03636C1.47167 8.96364 8.00259 13 8.00259 13C8.00259 13 13.7755 9.29091 14.8251 5.69091C14.9356 5.35495 14.9945 5.00601 15 4.65455V4.65455Z"
                                stroke="white" stroke-linecap="round" stroke-linejoin="round"></path>
                        </svg></span></button><span data-v-589d9d3d="" data-v-905a027d="" class="fs"
                    data-tid="game-name" style="--69ca8741: 16px;"><span data-v-905a027d="" data-v-589d9d3d-s="">Galaxy
                        Fishing</span></span></div>
            <div data-v-905a027d="" class="game-menu"><button data-v-517ae0ee="" data-v-905a027d=""
                    class="a-button toolbar" data-tid="game-fullscreen"><span data-v-905a027d="" class="nuxt-icon"><svg
                            width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M13.7 2H17.3L13.4 5.9C13.2 6.1 13.2 6.4 13.4 6.6C13.5 6.7 13.6 6.7 13.8 6.7C14 6.7 14.1 6.7 14.2 6.6L18 2.7V6.3C18 6.6 18.2 6.8 18.5 6.8C18.8 6.8 19 6.6 19 6.3V1.5C19 1.4 19 1.2 18.9 1.1C18.8 1 18.6 1 18.5 1H13.8C13.5 1 13.3 1.2 13.3 1.5C13.3 1.8 13.5 2 13.7 2Z"
                                fill="white"></path>
                            <path
                                d="M6.3 18.0002H2.7L6.6 14.1002C6.8 13.9002 6.8 13.6002 6.6 13.4002C6.4 13.2002 6.1 13.2002 5.9 13.4002L2 17.3002V13.7002C2 13.4002 1.8 13.2002 1.5 13.2002C1.2 13.2002 1 13.5002 1 13.7002V18.4002C1 18.5002 1 18.7002 1.1 18.8002C1.2 19.0002 1.4 19.0002 1.5 19.0002H6.2C6.5 19.0002 6.7 18.8002 6.7 18.5002C6.8 18.2002 6.5 18.0002 6.3 18.0002Z"
                                fill="white"></path>
                            <path
                                d="M19 13.7002C19 13.4002 18.8 13.2002 18.5 13.2002C18.2 13.2002 18 13.4002 18 13.7002V17.3002L14.1 13.4002C13.9 13.2002 13.6 13.2002 13.4 13.4002C13.2 13.6002 13.2 13.9002 13.4 14.1002L17.3 18.0002H13.7C13.4 18.0002 13.2 18.2002 13.2 18.5002C13.2 18.8002 13.4 19.0002 13.7 19.0002H18.4C18.5 19.0002 18.7 19.0002 18.8 18.9002C18.9 18.8002 18.9 18.7002 18.9 18.5002V13.7002H19Z"
                                fill="white"></path>
                            <path
                                d="M6.3 1H1.5C1.4 1 1.2 1 1.1 1.1C1 1.2 1 1.4 1 1.5V6.2C1 6.5 1.2 6.7 1.5 6.7C1.8 6.7 2 6.5 2 6.3V2.7L5.9 6.6C6 6.7 6.1 6.8 6.3 6.8C6.5 6.8 6.6 6.8 6.7 6.7C6.9 6.5 6.9 6.2 6.7 6L2.7 2H6.3C6.6 2 6.8 1.8 6.8 1.5C6.8 1.2 6.5 1 6.3 1Z"
                                fill="white"></path>
                        </svg>
                    </span></button><!----></div>
        </div>
        <div data-v-905a027d="" class="main">
            <div data-v-905a027d="" class="game">
                <div data-v-905a027d="" class="game-iframe"><iframe name="1743900066" id="main-game-frame"
                        src="https://ngstatic.com/enter.html?game=573&amp;userId=735550313333&amp;wshost=wss%3A%2F%2Ffnrz-gs.netgamenv.com&amp;quality=hd&amp;fnrz=true&amp;lang=en&amp;customJs=https://funrize.com/clientJS/dist/funrize/mobile.min.v1.65.16-swt.js&amp;isGuest=&amp;homelink=https://funrize.com/&amp;target=top&amp;fullscreen=false&amp;extdata=eyJjaGVja0lzTG9naW5VcmwiOiJcL2Nhc2hcL3ByZVwvbG9naW5cLyIsImxhbmd1YWdlIjoiZW4iLCJhYVRva2VuIjoiY1hqakVCbzh6MXA0eXhSeFgzbHRnQXBDYTkzYVZIbjEifQ%3D%3D"
                        frameborder="0" vspace="0" hspace="0" marginwidth="0" marginheight="0" seamless=""></iframe>
                </div>
                <!----><!----><!---->
            </div><!---->
        </div>
    </div>

</template>

<style>
    .leftBar {
        -webkit-text-size-adjust: 100%;
        --cairo: #d44784;
        --cannes: #fff;
        --cali: rgba(212, 71, 132, .85);
        --chennai: #cb41a3;
        --changchun: #7d77e9;
        --chattogram: #07bd3a;
        --cape: #3287d8;
        --changzhou: #ff7917;
        --casablanca: rgba(10, 11, 51, .7);
        --changsha: #090a34;
        --caracas: rgba(171, 183, 224, .6);
        --chicago: #ca61ac;
        --coimbatore: #ffc700;
        --camayenne: rgba(212, 71, 132, 0);
        --conakry: #abb7e0;
        --chaozhou: #141756;
        --curitiba: #080934;
        --changshu: #232561;
        --cixi: #00ff63;
        --ciputat: hsla(0, 0%, 100%, .7);
        --calgary: hsla(0, 0%, 100%, .4);
        --changde: hsla(0, 0%, 100%, .3);
        --chile: hsla(0, 0%, 100%, .2);
        --cordoba: hsla(0, 0%, 100%, .1);
        --changzhi: rgba(203, 65, 163, .15);
        --cileunyi: hsla(0, 0%, 100%, .07);
        --celaya: hsla(0, 0%, 100%, .05);
        --copenhagen: #07082b;
        --congo: #0b0c37;
        --canberra: #58617e;
        --charlotte: #6e768f;
        --cracow: #1f1f34;
        --chisinau: rgba(171, 183, 224, .8);
        --colombo: #232561;
        --callao: transparent;
        --cochin: rgba(7, 8, 43, .85);
        --campinas: #000;
        --chandigarh: rgba(0, 0, 0, .5);
        --cartagena: #1bc300;
        --comilla: #7d77e9;
        --chiba: rgba(212, 71, 132, .15);
        --cocio: #141416;
        --cairns: #642fe3;
        --coventry: #393d68;
        --camaguey: #c8494e;
        --chongjin: rgba(171, 183, 224, .3);
        --chimbote: rgba(171, 183, 224, .8);
        --chas: #6525b7;
        --chofu: #9654ea;
        --cadiz: rgba(171, 183, 224, .1);
        --concord: #6965bb;
        --ciamis: rgba(35, 37, 97, .4);
        --caen: #0475e7;
        --citeureup: #f0f0f2;
        --centennial: #3c87e8;
        --chuncheon: rgba(0, 0, 0, .25);
        --cabo: #fe8d3a;
        --calama: #3a3f69;
        --curug: #0e0f3c;
        --chiniot: rgba(203, 65, 163, .15);
        --choloma: #0e0f3c;
        --chapra: #00d95f;
        --columbus: #24ef6e;
        --cumana: rgba(171, 183, 224, .4);
        --cusena: #3e4083;
        --carson: #2e316c;
        --cocoa: #dadada;
        --chimoio: #f805af;
        --campeche: rgba(239, 8, 216, .4);
        --corum: #f538b5;
        --cary: rgba(248, 5, 175, .1);
        --carrara: #448aff;
        --cacem: #090b2a;
        --caceres: #642fe3;
        --cambe: rgba(15, 16, 61, .5);
        --cucuta: #622fe3;
        --cagliari: rgba(7, 8, 43, .4);
        --chittagong: #ffc700;
        --colima: rgba(125, 119, 233, .2);
        --cuttack: #161735;
        --cuba: rgba(248, 5, 175, .3);
        --china: rgba(0, 0, 0, .8);
        --cebal: #fb6262;
        --crato: #46d37d;
        --chlef: rgba(0, 0, 0, .8);
        --cepu: #0c0548;
        --cebu: #009ac5;
        --crosby: hsla(0, 0%, 100%, .1);
        --canton: #160641;
        --colton: rgba(171, 183, 224, .5);
        --chico: #10054b;
        --cagli: #4c12b3;
        --chemnitz: #000;
        --campo: #1d9bf0;
        --cheonan: #0778ff;
        --cankaya: #e3e9ef;
        --cando: #572504;
        --catar: #0b3a0f;
        --cheng: #4c13b4;
        --clara: #5f082b;
        --casab: #01c293;
        --changping: #000121;
        --changling: #4c50bd;
        --cimahi: rgba(0, 0, 0, .06);
        --carora: #0a0b39;
        --chuzhou: #bac7dd;
        --chinatown: #161740;
        --compton: #e1ecff;
        --carpi: hsla(0, 0%, 100%, .08);
        --closepet: #131948;
        --conroe: #652fe2;
        --chitose: #8581fc;
        --coronel: rgba(0, 0, 0, .3);
        --caringin: #848db7;
        --calumpit: #292c72;
        --cardenas: rgba(9, 11, 42, .64);
        --caint: #630f03;
        --cavan: rgba(75, 25, 165, .75);
        --cusco: #290f62;
        --сhandler: #e84435;
        --calan: #bac4cf;
        --aruaru: #f18e1d;
        --calamba: #fab93b;
        --crawley: #a0390a;
        --columbia: #1e4b09;
        --cubatao: rgba(18, 34, 14, .5);
        --chamberi: #fffe00;
        --concepcion: rgba(186, 199, 221, .3);
        --clovis: #006b17;
        --cainta: #70af16;
        --cortazar: rgba(68, 138, 255, .1);
        --chusovoy: #65ecff;
        --chomutov: #072757;
        --carsamba: #680099;
        --culiacan: #bac7dd;
        --сhifeng: rgba(3, 5, 8, .8);
        --centralniy: #a82b17;
        --cabimas: rgba(255, 168, 0, .8);
        --chifeng: #4f25b5;
        --cotabato: #e501ef;
        --cikampek: #2a004b;
        --cacak: rgba(0, 0, 0, .6);
        --chitungwiza: #1e0355;
        --cranston: #21235b;
        --carrollton: #f90;
        --contagem: #380084;
        --corrientes: #0d0c80;
        --cubuk: #09ab55;
        --cheboksary: #00ff63;
        --carrefour: #ff53cb;
        --caucaia: #1e67b8;
        --chengzhong: #d34355;
        --callito: #4905a6;
        --chanthaburi: #1b0165;
        --carpina: #0d043d;
        --contramaestre: #1b0166;
        --neutral-0: #090b2a;
        --neutral-5: #0d0d2e;
        --neutral-15: #161740;
        --neutral-20: #24244e;
        --neutral-30: #3e3e61;
        --neutral-40: #57577b;
        --neutral-50: #6d6d93;
        --neutral-70: #a5a5d9;
        --neutral-80: #c0c0e2;
        --neutral-99: #fbfbff;
        --neutral-100: #fff;
        --neutral-500: #1838e5;
        --neutral-800: #0d1f80;
        --secondary-20: #49259e;
        --secondary-25: #642fe3;
        --secondary-40: #736de1;
        --secondary-50: #7d77e9;
        --secondary-100: #fff;
        --success-50: #00ff63;
        --secondary-80: #afaaff;
        --primary-30: #b90b85;
        --primary-40: #de099e;
        --primary-50: #f805af;
        --custom-c1: #01a5c2;
        --custom-c2: #009ac5;
        --custom-c3: #453bff;
        --error-50: #e50037;
        --tertiary-30: #fe8d3a;
        --tertiary-50: #ffc700;
        --tertiary-60: #fee105;
        --color-text-title: #58617e;
        --overlay-008: hsla(0, 0%, 100%, .08);
        --overlay-016: hsla(0, 0%, 100%, .16);
        --overlay-020: rgba(9, 11, 42, .2);
        --ganduras: linear-gradient(270deg, var(--cairo) 0%, var(--chennai) 100%);
        --gilbert: linear-gradient(180deg, var(--chaozhou), var(--curitiba));
        --giza: linear-gradient(180deg, #fff8bd, #ffd600 43.96%, #de8500 50.41%, #ffd600 59.36%, #f90);
        --ghana: linear-gradient(180deg, #ccff8b, #42ff00);
        --gdansk: linear-gradient(180deg, #403ab8, #373290);
        --ganzhou: linear-gradient(180deg, #514fd8, #1a1d57);
        --glasgow: linear-gradient(135deg, #dd1b00, #fa8700);
        --gdynia: linear-gradient(180deg, #0f113e, #090a34);
        --genoa: linear-gradient(180deg, #10154f, #090c3b);
        --gaya: linear-gradient(270deg, var(--cucuta), #f805af);
        --galati: linear-gradient(#fff 0 0) padding-box, linear-gradient(#fff 0 0);
        --goma: linear-gradient(104deg, #0c0548, #29015d 102%);
        --graz: linear-gradient(180deg, #141756, #080934);
        --ghent: linear-gradient(180deg, #090c2b, #111140 25.66%, #1f1d6d 49.81%, #111140 70.36%, #090b2a 90.77%);
        --guli: linear-gradient(180deg, #403ab8 -8.5%, #1d1c5d 46.79%, #090b2a 102.5%);
        --geneva: linear-gradient(135deg, var(--cucuta), #d200ca);
        --gondar: linear-gradient(138deg, #0c0548, #29015d);
        --gijon: linear-gradient(270deg, #622fe3, #3200b0);
        --gent: linear-gradient(316deg, #731912, #20056b);
        --gusau: linear-gradient(138deg, #1b0353, #384995);
        --guatire: linear-gradient(314deg, #ee8100, #750000);
        --geneve: linear-gradient(314deg, #3d00a1, #6361c2);
        --groningen: linear-gradient(314deg, #499cf5, #4a46fb 59.38%, #090694);
        --gulu: linear-gradient(314deg, #a4008b, #1b0353);
        --gaomi: linear-gradient(316deg, #a4008b 6.25%, #6204b6 46.66%, #141da3);
        --gloucester: linear-gradient(180deg, #fcde34, #eb712a);
        --guilin: linear-gradient(218deg, #0029ff 22%, #2cd8fe 92%);
        --gwalior: linear-gradient(270deg, #ffb800, #f9239e 99.99%, #f805af);
        --greenville: linear-gradient(180deg, #403ab8, #373290);
        --gashua: linear-gradient(180deg, #34d8fc, #452aeb);
        --gweru: linear-gradient(180deg, rgba(36, 2, 74, 0) -6%, #24024a 71.19%);
        --godhra: linear-gradient(180deg, #141755 33.58%, rgba(20, 23, 85, 0));
        --gisenyi: linear-gradient(103.55deg, #0c0548, #29015d 101.85%);
        --gimcheon: linear-gradient(180deg, #dd1b00, #fa8700);
        --gyumri: linear-gradient(104deg, #0c0548, #29015d 102%);
        --guider: linear-gradient(270deg, #ffb503, #f9289a);
        --gotenba: linear-gradient(180deg, #403ab8, #0e0f3c);
        --galesong: linear-gradient(98deg, #10086c 32.66%, #360448 123.78%);
        --gangapur: linear-gradient(180deg, #fffe00, #ffac05);
        --ghardaia: linear-gradient(180deg, #ff78e9, #f300bd);
        --ghaziabad: linear-gradient(180deg, #30fbc9 -50.92%, #01c293 155.85%);
        --guyong: linear-gradient(180deg, #2874e3 32.34%, #4b03c0 57.01%, #090b2a 75.99%);
        --glendale: linear-gradient(272deg, #4f22bc, #004bc9);
        --gorgan: linear-gradient(103deg, #024bc9, #4f23bc 82.38%);
        --ganganagar: linear-gradient(270deg, #26025b, #26025b 73.5%, #12054d);
        --gatchina: linear-gradient(90deg, #00993b, #00ff63);
        --guiguinto: linear-gradient(180deg, #00ff63, #00993b);
        --georgiyevsk: -webkit-linear-gradient(0deg, #f805af 25%, #622fe3 65%, #622fe3);
        --gbongan: linear-gradient(104deg, #003358, #007e9a 101.85%);
        --guadalupe: linear-gradient(180deg, rgba(8, 70, 12, 0) 45.71%, #023204 64.88%);
        --garoua: linear-gradient(270deg, #622fe3, #f805af);
        --gwangju: linear-gradient(104deg, #0c0548, #29015d 101.85%);
        --gandia: linear-gradient(104deg, #410089, #db00ff 87.47%);
        --glendora: linear-gradient(180deg, #13000b, #13000b 40%, #4c0098 80.18%);
        --guetersloh: linear-gradient(104deg, #020d77, #121dd1 101.85%);
        --garcia: linear-gradient(287deg, #3000b9 2.1%, #000c76 54.23%);
        --gyor: linear-gradient(180deg, #595aff -1.33%, #311bba 59.33%, #2f1ca7 98.29%);
        --giessen: linear-gradient(180deg, #642fe3 70.78%, #4a22ab 94.99%);
        --gulariya: linear-gradient(180deg, #fff 70.78%, #e7ebf2 94.99%);
        --gostivar: linear-gradient(135deg, #1b0353 3.75%, #7c00c9 96.25%);
        --gushikawa: linear-gradient(282deg, #d4007f 0.83%, #690972 28.23%, #13064e 99.48%);
        --goru: radial-gradient(158.82% 129.17% at 50% -20.83%, #3efe74 16.91%, #e7ffc9 36.26%, #f3ffe6 44.93%, #c8ffd1 47.67%, #c5ff98 49.81%, #02c255 73.69%);
        --gandhidham: linear-gradient(90deg, #f6d111 3.47%, #f805af);
        --gbadolite: linear-gradient(104deg, #0187a5, #29015d 101.85%);
        --ginowan: linear-gradient(104deg, #0187a5, #45039a 101.85%);
        --ghazipur: linear-gradient(180deg, #540468, #f105ac);
        --gondal: linear-gradient(180deg, #042515, #019f51);
        --gainesville: radial-gradient(158.82% 129.17% at 50% -20.83%, #fbb80d 16.91%, #fff47e 36.26%, #fff5cb 44.93%, #ffec3f 47.67%, #ffd042 49.81%, #fff64a 73.69%);
        --goty: linear-gradient(180deg, #cdffcb, #52ea30);
        --gradient-g-2: linear-gradient(138deg, #0c0548 2.98%, #29015d 92.76%);
        --font-family: Outfit, Helvetica Neue, Helvetica, Arial, sans-serif;
        --scrollbar-width: 4px;
        --scrollbar-thumb-width: 4px;
        --scrollbar-thumb-background: var(--canberra);
        --support-chat-color: var(--chemnitz);
        --support-chat-color-hover: var(--chemnitz);
        --support-chat-background: var(--chimoio);
        --support-chat-background-hover: var(--chimoio);
        --toastify-color-light: #fff;
        --toastify-color-info: #3498db;
        --toastify-color-success: #07bc0c;
        --toastify-color-warning: #f1c40f;
        --toastify-color-error: #e74c3c;
        --toastify-color-transparent: hsla(0, 0%, 100%, .7);
        --toastify-icon-color-info: var(--toastify-color-info);
        --toastify-icon-color-success: var(--toastify-color-success);
        --toastify-icon-color-warning: var(--toastify-color-warning);
        --toastify-icon-color-error: var(--toastify-color-error);
        --toastify-toast-background: #fff;
        --toastify-toast-max-height: 800px;
        --toastify-text-color-info: #fff;
        --toastify-text-color-success: #fff;
        --toastify-text-color-warning: #fff;
        --toastify-text-color-error: #fff;
        --toastify-spinner-color: #616161;
        --toastify-spinner-color-empty-area: #e0e0e0;
        --toastify-color-progress-light: linear-gradient(90deg, #4cd964, #5ac8fa, #007aff, #34aadc, #5856d6, #ff2d55);
        --toastify-color-progress-dark: #bb86fc;
        --toastify-color-progress-info: var(--toastify-color-info);
        --toastify-color-progress-success: var(--toastify-color-success);
        --toastify-color-progress-warning: var(--toastify-color-warning);
        --toastify-color-progress-error: var(--toastify-color-error);
        --toastify-color-progress-colored: #ddd;
        --a-text-link-color: var(--changchun);
        --a-button-default-cursor: pointer;
        --a-button-default-border-width: 1px;
        --a-button-default-border-style: solid;
        --a-button-default-border-color: var(--cairo);
        --a-button-default-box-shadow: 0px 4px 10px 0px rgba(0, 0, 0, .16);
        --a-button-default-color: var(--cannes);
        --a-button-default-font-weight: bold;
        --a-button-default-font-size: 16px;
        --a-button-default-outline: none;
        --a-button-default-border-radius: 22px;
        --a-button-default-border-radius-lg: 22px;
        --a-button-default-padding: 8px 16px;
        --a-button-default-background: var(--changsha);
        --a-button-default-text-shadow: none;
        --a-button-default-hover-background: var(--colima);
        --a-button-default-text-transform: none;
        --a-button-primary-box-shadow: 0px 2px 10px var(--campeche);
        --a-button-primary-color: var(--cannes);
        --a-button-primary-background: var(--chimoio);
        --a-button-primary-hover-background: var(--corum);
        --a-button-primary-before-content: none;
        --a-button-primary-hover-box-shadow: var(--a-button-primary-box-shadow);
        --a-button-primary-disabled-box-shadow: none;
        --a-button-primary-disabled-border-color: var(--a-button-default-border-color);
        --a-button-primary-border-width: var(--a-button-default-border-width);
        --a-button-primary-active-background: var(--chimoio);
        --a-button-primary-disabled-color: var(--a-button-primary-color);
        --a-button-primary-disabled-background: var(--a-button-primary-background);
        --a-button-disabled-background: var(--canberra);
        --a-button-disabled-color: var(--cannes);
        --a-button-disabled-hover-background: var(--charlotte);
        --a-button-disabled-font-weight: normal;
        --a-button-disabled-opacity: .5;
        --a-button-disabled-pointer-events: none;
        --a-button-navigation-color: var(--chisinau);
        --a-button-navigation-active-color: var(--cannes);
        --a-button-navigation-hover-color: var(--chisinau);
        --a-button-navigation-font-size: 12px;
        --a-button-navigation-line-height: 14px;
        --a-button-navigation-font-size-sm: 12px;
        --a-button-navigation-line-height-sm: 14px;
        --a-button-navigation-font-weight: 400;
        --a-button-navigation-text-transform: inherit;
        --a-button-navigation-background: var(--colombo);
        --a-button-navigation-hover-background: var(--colombo);
        --a-button-navigation-active-background: var(--caceres);
        --a-button-navigation-active-font-weight: 700;
        --a-button-navigation-border-color: var(--colombo);
        --a-button-navigation-active-border-color: var(--caceres);
        --a-button-navigation-border-radius: 10px;
        --a-button-navigation-padding: 6px 20px 6px;
        --a-button-navigation-padding-xs: 6px 7px 8px;
        --a-button-navigation-min-width: 124px;
        --a-button-navigation-min-width-md: 124px;
        --a-button-navigation-hover-opacity: 1;
        --a-button-navigation-svg-fill: var(--cannes);
        --a-button-not-navigation-svg-fill: var(--cannes);
        --a-button-toolbar-background: var(--caceres);
        --a-button-toolbar-background-active: var(--caceres);
        --a-button-toolbar-border-radius: 6px;
        --a-button-toolbar-padding: 6px 8px;
        --a-button-toolbar-box-shadow: 0px 2px 10px var(--cagliari);
        --a-button-toolbar-svg-size: 16px;
        --a-button-toolbar-svg-fill: var(--cannes);
        --a-button-toolbar-svg-stroke: var(--comilla);
        --a-button-toolbar-border: none;
        --a-button-toolbar-border-active: none;
        --a-button-toolbar-opacity: .85;
        --a-button-outline-hover-background: var(--cary);
        --a-button-outline-color: var(--cannes);
        --a-button-outline-border-color: var(--chennai);
        --a-button-outline-background: transparent;
        --a-button-outline-padding: 8px 16px;
        --a-button-outline-padding-small: var(--a-button-outline-padding);
        --a-button-outline-before-content: "";
        --a-button-outline-border-width: 0px;
        --a-button-outline-before-background: var(--gaya);
        --a-button-outline-hover-before-opacity: 1;
        --a-button-outline-disabled-border-color: transparent;
        --a-button-outline-disabled-opacity: .5;
        --a-button-outline-disabled-color: var(--cannes);
        --a-button-secondary-background: var(--cileunyi);
        --a-button-secondary-hover-background: var(--cileunyi);
        --a-button-secondary-border-width: 0px;
        --a-button-secondary-padding: 9px 16px;
        --a-button-secondary-border-radius: 10px;
        --a-button-secondary-color: var(--cannes);
        --a-button-secondary-hover-color: var(--cannes);
        --a-button-secondary-box-shadow: 0px 11px 18px var(--chuncheon);
        --a-button-secondary-box-shadow-hover: 0px 11px 18px var(--chuncheon);
        --a-button-success-background: var(--chapra);
        --a-button-success-hover-background: var(--columbus);
        --a-button-success-box-shadow: none;
        --a-button-success-text-shadow: none;
        --a-button-success-color: var(--cannes);
        --a-button-loading-size: 28px;
        --a-button-size-2xl-border-radius: var(--a-button-default-border-radius);
        --a-button-size-xl-border-radius: var(--a-button-default-border-radius);
        --a-button-size-lg-border-radius: var(--a-button-default-border-radius);
        --a-button-size-md-border-radius: var(--a-button-default-border-radius);
        --a-button-size-small-border-radius: 8px;
        --a-button-size-2xl-height: 60px;
        --a-button-size-xl-height: 56px;
        --a-button-size-lg-height: 48px;
        --a-button-size-md-height: 40px;
        --a-button-size-small-height: 32px;
        --a-button-size-x-small-height: 28px;
        --a-skeleton-border-radius: 8px;
        --a-corner-badge-default-text-color: var(--cannes);
        --a-corner-badge-background: var(--covel);
        --a-corner-badge-default-width: 65px;
        --a-corner-badge-default-height: 55px;
        --a-corner-badge-default-transform: translate(-17%, -13%) rotate(-41deg);
        --a-corner-badge-right-transform: translate(16%, -12%) rotate(42deg);
        --a-corner-badge-default-color: var(--cannes);
        --a-corner-badge-default-border-width: 55px 65px 0 0;
        --a-corner-badge-default-before-width: 0px;
        --a-corner-badge-default-font-size: 10px;
        --a-corner-badge-default-font-style: normal;
        --a-corner-badge-default-text-shadow: none;
        --a-corner-badge-success-border-color: var(--cixi) transparent transparent transparent;
        --a-corner-badge-warning-border-color: var(--changzhou) transparent transparent transparent;
        --a-corner-badge-info-border-color: var(--cape) transparent transparent transparent;
        --a-corner-badge-secondary-border-color: var(--comilla) transparent transparent transparent;
        --a-corner-badge-detail-border-color: var(--coimbatore) transparent transparent transparent;
        --a-corner-badge-default-radius: 4px;
        --a-corner-badge-accent-background: var(--glasgow);
        --a-corner-badge-custom-background: var(--geneva);
        --a-corner-badge-extra-background: var(--guilin);
        --a-badge-default-color: var(--cannes);
        --a-badge-default-background: var(--chimoio);
        --a-badge-default-radius: 50%;
        --a-badge-default-padding: 0;
        --a-badge-info-height: auto;
        --a-badge-info-line-height: 16px;
        --a-badge-info-padding: 2px 4px;
        --a-badge-info-radius: 4px;
        --a-badge-info-shadow: 0 11px 18px rgba(0, 0, 0, .25);
        --a-badge-info-color: var(--cocio);
        --a-badge-info-border-width: 0;
        --a-badge-info-border-color: transparent;
        --a-badge-skew-size: auto;
        --a-badge-skew-height: 20px;
        --a-badge-skew-padding: 0 10px 0 12px;
        --a-badge-skew-border-radius: 3px;
        --a-badge-skew-before-content: "";
        --a-popper-default-background-color: var(--cracow);
        --a-popper-default-background-color-hover: var(--cracow);
        --a-popper-default-text-color: var(--conakry);
        --a-popper-default-border-width: 0px;
        --a-popper-default-border-style: solid;
        --a-popper-default-border-radius: 5px;
        --a-popper-default-border-color: transparent;
        --a-popper-default-padding: 8px;
        --a-popper-default-box-shadow: none;
        --a-popper-default-font-weight: 400;
        --popper-theme-background-color: var(--a-popper-default-background-color);
        --popper-theme-background-color-hover: var(--a-popper-default-background-color-hover);
        --popper-theme-text-color: var(--a-popper-default-text-color);
        --popper-theme-border-width: var(--a-popper-default-border-width);
        --popper-theme-border-style: var(--a-popper-default-border-style);
        --popper-theme-border-radius: var(--a-popper-default-border-radius);
        --popper-theme-border-color: var(--a-popper-default-border-color);
        --popper-theme-padding: var(--a-popper-default-padding);
        --popper-theme-box-shadow: var(--a-popper-default-box-shadow);
        --a-animation-pulse-box-shadow-color: var(--camayenne);
        --a-header-background: var(--casablanca);
        --a-header-background-md: var(--a-header-background);
        --a-header-backdrop-filter: blur(14px);
        --a-overlay: var(--cochin);
        --a-overlay-cursor: pointer;
        --a-card-default-radius: 10px;
        --a-card-default-top-padding: 59px 20px 0;
        --a-card-default-bottom-padding: 0px 20px 38px;
        --a-card-default-bottom-gap: 0px;
        --a-card-default-top-gap: 6px;
        --a-card-default-align-items: flex-start;
        --a-card-img-top: 0;
        --a-card-img-bottom: 0;
        --a-card-img-left: 0;
        --a-card-img-right: 0;
        --a-card-img-width: 100%;
        --a-card-img-height: 100%;
        --a-card-game-radius: 10px;
        --a-card-game-width: auto;
        --a-card-game-height: auto;
        --a-card-game-container-background: var(--cochin);
        --a-card-game-locked-background: var(--chandigarh);
        --a-card-game-locked-border-radius: 16px;
        --a-card-game-border-radius: 16px;
        --a-card-game-locked-blur: 4px;
        --a-card-game-border: none;
        --a-card-game-shadow: none;
        --a-divider-default-background: var(--cordoba);
        --a-toggle-track-background-color: var(--conakry);
        --a-toggle-thumb-background-color: var(--conakry);
        color-scheme: light dark;
        --cash-input-text-color: #161740;
        --cash-input-background: #fff;
        --toastify-color-dark: var(--cracow);
        --toastify-toast-width: 345px;
        --toastify-toast-min-height: 52px;
        --toastify-text-color-light: var(--cracow);
        --toastify-text-color-dark: var(--cannes);
        --toastify-font-family: var(--font-family);
        --o-sidebar-width: 232px;
        --o-modals-z-index: 9999;
        --toastify-z-index: 10001;
        --a-skeleton-background-color: var(--colombo);
        --m-fund-entries-color: var(--cixi);
        --m-fund-coins-color: var(--coimbatore);
        --a-button-group-border-radios: 10px;
        --a-button-group-background: var(--cordoba);
        --a-button-group-gap: 0;
        font-family: var(--font-family);
        line-height: 1.2;
        -webkit-tap-highlight-color: transparent;
        --top-height: 0;
        --4a085039: var(--china);
        cursor: auto;
        box-sizing: inherit;
        color: var(--cannes);
        display: flex;
        flex-direction: column;
        width: 100%;
        border-radius: 0;
        height: 100%;
        max-height: none;
    }
</style>