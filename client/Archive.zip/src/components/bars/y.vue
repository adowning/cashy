<template>
  <div data-v-c630237a="" class="main">
    <div data-v-c630237a="" class="game">
      <div data-v-c630237a="" class="game-iframe">
        <iframe
          src="https://gsgeneral-ad2.ppgames.net/gs2c/playGame.do?key=token%3DFUN3f7358c87738ed9b618c2975%60%7C%60symbol%3Dvs20bblitz%60%7C%60language%3Den%60%7C%60currency%3DGCC%60%7C%60lobbyUrl%3Dhttps%3A%2F%2Ffunrize.com&amp;ppkv=2&amp;stylename=netg_funrizegc&amp;treq=rQC2TZzvTzrfdMMC1tJxtEoG1ktktvsXf6VlBsFz2IYyoBVhIvgbomt27exuhsz5&amp;isGameUrlApiCalled=true&amp;userId=5401084"
          frameborder="0" vspace="0" hspace="0" marginwidth="0" marginheight="0" seamless="true"
/>
        </div>
      <!----><!----><!---->
    </div><!---->
  </div>
</template>
