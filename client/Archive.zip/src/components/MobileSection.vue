<script setup>
import { containerMaxW } from '@/composables/maxWidth'
</script>

<template>
  <div class="relative flex grow-1 flex-col m-0 p-0 w-screen min-h-screen overflow-hidden">
    <slot />
  </div>
</template>
