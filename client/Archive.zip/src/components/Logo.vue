<script setup lang="ts"></script>

<template>
  <div>
    <img class="w-[100%] max-w-[480px] m-auto" src="@/assets/logo.png" />
  </div>
</template>
