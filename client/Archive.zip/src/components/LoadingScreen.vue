<template>
    <div class="overlay flex flex-col items-center justify-center">
        <img src="/images/items/common/vertin-wheel.apng" alt="Loading">
        <h1 class="text-white text-2xl mt-4 font-bold"> Loading... </h1>
    </div>
</template>

<style scoped></style>
