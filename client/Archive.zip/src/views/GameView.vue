<!-- eslint-disable vue/html-indent -->
<script setup lang="ts">
import GameLayout from '@/layouts/GameLayout.vue'

onMounted(() => {
})
</script>

<template>
    <GameLayout>
        <slot />
    </GameLayout>
</template>
